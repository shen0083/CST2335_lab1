package zhentingmai.androidfinalproject;

import android.os.Bundle;
import android.app.Activity;

import sulijin.androidfinalproject.R;

public class AutomobileActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_automobile);
    }

}
